<?php

require_once 'dbinc.php';

class Szemely{
    private $szemelyid;
    private $nev;

    public function getNev(){
        $sql = "SELECT nev FROM szemelyek WHERE szemelyid = ".$szemelyid;
        if($resultnev = $db->dbselect($sql)){
            $szemelysor = $resultnev->fetch_assoc();
            $this->nev = $szemelysor['nev'];
            $this->szemelyid = $szemelyid;
        }
        return $this->nev;
    }


    public function nevetKeres($szoveg, $db){ 
        $talalatok = array();
        $sql = "SELECT szemelyid FROM szemelyek WHERE nev LIKE '%$szoveg%'";
        if($result = $db->dbselect($sql)){
            while($row = $result->fetch_assoc()){
                $talalatok[$row['szemelyid']] = $row['nev'];
            }
    
        }
        
    return $talalatok;
    }
}
?>